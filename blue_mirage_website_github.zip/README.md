# Blue Mirage Packaging Limited website

Upload `index.html` and the full `assets` folder to the root of your existing GitHub repository, replacing the previous `index.html`. Commit to `main`. In Settings → Pages, select `main` and `/(root)` if not already enabled.

This design follows your supplied reference image. Product images are cropped from the reference and should ideally be replaced with original high-resolution product photos. The quote form opens the visitor's email application; it does not store enquiries on a server.
